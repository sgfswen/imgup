<?php

return array(
    // Bootstrap the configuration file with AWS specific features
    'includes' => array('_aws'),
    'services' => array(
        // All AWS clients extend from 'default_settings'. Here we are
        // overriding 'default_settings' with our default credentials and
        // providing a default region setting.
        'default_settings' => array(
            'params' => array(
                'credentials' => array(
                    'key'    => 'AKIAIESUB7SWZ6ZWSAPA',
                    'secret' => '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',
                ),
                'region' => 'us-east-2'
            )
        )
    )
);