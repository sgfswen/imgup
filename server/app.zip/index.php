<!DOCTYPE html>
<html lang="en"><head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>Imgup</title>
    <link rel="shortcut icon" href="">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto|Rubik">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://code.getmdl.io/1.2.1/material.deep_purple-cyan.min.css">
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <link href="https://s3.us-east-2.amazonaws.com/wfpublic/imgup/css/main.6acc092c.css" rel="stylesheet"></head>
<body>
<div id="root"></div>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.3.7/js/tether.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0-alpha.5/js/bootstrap.min.js"></script>
<script defer="defer" src="https://code.getmdl.io/1.2.1/material.min.js"></script>
<script type="text/javascript" src="https://s3.us-east-2.amazonaws.com/wfpublic/imgup/js/main.57c3da57.js"></script>
</body>
</html>